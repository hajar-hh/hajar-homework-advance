import { Container } from "react-bootstrap";
function Logout() {
  return (
    <Container>
      <h1>Logout</h1>
    </Container>
  );
}
export default Logout;
